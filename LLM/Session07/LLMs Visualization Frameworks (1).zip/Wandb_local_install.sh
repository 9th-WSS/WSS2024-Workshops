#!/bin/bash
wandb server start -e HOST=http://localhost:port
